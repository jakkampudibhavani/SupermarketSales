#!/usr/bin/env python3
import sys
from collections import defaultdict

grouped_data = defaultdict(lambda: defaultdict(lambda: [0, 0]))

for line in sys.stdin:
    line = line.strip()
    parts = line.split('\t')

    group_id = int(parts[0])
    key = '\t'.join(parts[1:-2])
    quantity = int(parts[-2])
    total_sales = float(parts[-1])

    grouped_data[group_id][key][0] += quantity
    grouped_data[group_id][key][1] += total_sales

group_names = {
    1: "Branch , Product Line",
    2: "Gender, Product Line",
    3: "Month, Product Line",
    4: "City, Product Line",
    5: "Branch, City, Month, Gender, Product Line"
}

def print_group(group_id, data, k=None):
    print(f"==== {group_names[group_id]} ====")
    sorted_items = sorted(data.items(), key=lambda x: x[1][1], reverse=True)
    if k:
        sorted_items = sorted_items[:k]

    # Calculate maximum lengths for each column
    max_key_lengths = [max(len(part) for key in data.keys() for part in key.split('\t'))]
    max_quantity_length = max(len(str(values[0])) for _, values in sorted_items)
    max_sales_length = max(len(f"{values[1]:.2f}") for _, values in sorted_items)

    # Print header
    header_parts = group_names[group_id].split(', ')
    header = ' '.join(part.ljust(max_key_lengths[0]) for part in header_parts)
    print(f"{header}\tQuantity\tSales")
    print('-' * (sum(max_key_lengths) + max_quantity_length + max_sales_length + 100))

    for key, values in sorted_items:
        key_parts = key.split('\t')
        formatted_key = ' '.join(part.ljust(max_key_lengths[0]) for part in key_parts)
        formatted_quantity = str(values[0]).rjust(max_quantity_length)
        formatted_sales = f"{values[1]:.2f}".rjust(max_sales_length)
        print(f"{formatted_key}\t{formatted_quantity}\t\t{formatted_sales}")
    print()

for group_id in sorted(grouped_data.keys()):
    if group_id == 5:
        print(f"Top 15 sales")
        print_group(group_id, grouped_data[group_id], k=15)
    else:
        print_group(group_id, grouped_data[group_id], k=15)
