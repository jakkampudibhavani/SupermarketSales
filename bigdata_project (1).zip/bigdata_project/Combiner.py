#!/usr/bin/env python3
import sys
from collections import defaultdict

combined_data = defaultdict(lambda: [0, 0])

for line in sys.stdin:
    line = line.strip()
    parts = line.split('\t')

    group_id = parts[0]
    key = '\t'.join(parts[1:-2])
    quantity = int(parts[-2])
    total_sales = float(parts[-1])

    combined_key = f"{group_id}\t{key}"
    combined_data[combined_key][0] += quantity
    combined_data[combined_key][1] += total_sales

for key, values in combined_data.items():
    print(f"{key}\t{values[0]}\t{values[1]}")
