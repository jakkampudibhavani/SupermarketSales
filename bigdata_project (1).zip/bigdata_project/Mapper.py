#!/usr/bin/env python3
import sys
from datetime import datetime

for line in sys.stdin:
    line = line.strip()
    fields = line.split(',')

    if fields[0] == "Branch":
        continue

    branch = fields[0].strip()
    city = fields[1].strip()
    gender = fields[2].strip()
    product_line = fields[3].strip()
    quantity = int(fields[4].strip())
    total_sales = float(fields[5].strip())

    try:
        date = datetime.strptime(fields[6].strip(), "%m-%d-%Y")
    except ValueError:
        date = datetime.strptime(fields[6].strip(), "%m/%d/%Y")
    month = date.strftime("%B")

    print(f"1\t{branch}\t{product_line}\t{quantity}\t{total_sales}")
    print(f"2\t{gender}\t{product_line}\t{quantity}\t{total_sales}")
    print(f"3\t{month}\t{product_line}\t{quantity}\t{total_sales}")
    print(f"4\t{city}\t{product_line}\t{quantity}\t{total_sales}")
    print(f"5\t{branch}\t{city}\t{month}\t{gender}\t{product_line}\t{quantity}\t{total_sales}")
