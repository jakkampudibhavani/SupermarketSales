hdfs dfs -rm -r output/Project_output

hadoop jar /home/student/Downloads/hadoop-3.4.0/share/hadoop/tools/lib/hadoop-streaming-3.4.0.jar \
-files /home/student/Downloads/work/project/Mapper.py,/home/student/Downloads/work/project/Combiner.py,/home/student/Downloads/work/project/Reducer.py \
-mapper 'python3 Mapper.py' \
-combiner 'python3 Combiner.py' \
-reducer 'python3 Reducer.py' \
-input input/Dataset.csv \
-output output/Project_output

hdfs dfs -cat output/Project_output/part-00000
